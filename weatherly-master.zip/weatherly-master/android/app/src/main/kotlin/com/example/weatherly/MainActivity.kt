package com.example.weatherly

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
